#!/bin/bash
cat /proc/$PPID/maps > $1
